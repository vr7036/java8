# epam-Java8Lambdas_and_Streams
epam hometask - Java8 Lambdas and Streams
